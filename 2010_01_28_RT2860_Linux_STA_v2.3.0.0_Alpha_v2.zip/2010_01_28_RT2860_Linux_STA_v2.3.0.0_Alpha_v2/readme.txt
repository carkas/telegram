Driver install:

Please use following command ( # is comment line , after the  ">"  is command) to install driver

# extract driver

> tar zxvf 2010_01_28_RT2860_Linux_STA_v2.3.0.0_Alpha_v2.tar.gz

# enter the driver folder that just extract

> cd 2010_01_28_RT2860_Linux_STA_v2.3.0.0_Alpha_v2

# compile the driver (system need install kernel-header package, should be installed by default)

> make

# install the driver to system (need "root" right)

> make install

#plugin the DWA-525(PCI device) then the driver should be loadup by system.

# now user may use "networkmanager" to site survey and connect to AP.
